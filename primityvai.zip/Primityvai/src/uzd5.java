import java.util.Scanner;

public class uzd5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 Scanner reader = new Scanner(System.in);
		  System.out.print("Type a number n  ");
		   int n= reader.nextInt();
		 
		  System.out.println(Integer.toBinaryString(n));
		 
		  
		 
	}

}
