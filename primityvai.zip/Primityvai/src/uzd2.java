import java.util.Scanner;

public class uzd2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner reader = new Scanner(System.in);
		  System.out.print("Type a number");
		 float sk= reader.nextFloat();
		  
		  
	      int newsk = Math.round(sk);
	      
	      System.out.println("Atsakymas: " + newsk);
	      
	    	           	}
		  
		  
	}


