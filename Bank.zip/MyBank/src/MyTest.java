import ibank.Bank;
import ibank.BaseBankTest;

public class MyTest extends BaseBankTest {

	@Override
	protected Bank createBank() {
		// TODO Auto-generated method stub
		return new MyBank ();
	}

}
