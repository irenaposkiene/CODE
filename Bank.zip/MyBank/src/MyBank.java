
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import ibank.Account;
import ibank.Bank;

public class MyBank implements Bank {
	
	public List<Account> bankAccountList;
	
	
	

	public MyBank() {
	
		this.bankAccountList = new ArrayList<>();
	}
	
	@Override
	public void closeAccount(Account a) {
	
		if ( bankAccountList.contains(a))
			bankAccountList.remove(a);	
				
	}
	@Override
	public Account getAccountByHolderName(String name) {
		for (Account element:bankAccountList){
			if (element.getHolderName().equals(name)){
				return element;
			}
			
		}
		
		return null;
	}

	@Override
	public Account getAccountByNumber(String number) {
		for (Account element:bankAccountList){
			if (element.getNumber().equals(number)){
				return element;
			}
		}
		return null;
	}

	@Override
	public Collection<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return this.bankAccountList;
	}

	@Override
	public int getNumberOfAccounts() {
		// TODO Auto-generated method stub
		return this.bankAccountList.size();
	}

	@Override
	public BigDecimal getTotalReserves() {
		// TODO Auto-generated method stub
		BigDecimal sum = new BigDecimal(0);
		for (Account element:bankAccountList){
		sum= sum.add(element.getBalance());
				
			}
		return sum;
	}

	@Override
	public Account openCreditAccount(String name, BigDecimal limitas) {
		// TODO Auto-generated method stub
		Account account = new KredSaskaita(limitas, name); 
		
		if (getAccountByHolderName (name) == null) {
		bankAccountList.add(account);
		return account;
		}
		return null;
	}

	@Override
	public Account openDebitAccount(String name) {
		// TODO Auto-generated method stub
		Account account = new Saskaita (name); 
		
		if (getAccountByHolderName (name) == null) {
			bankAccountList.add(account);
			return account;
		}
		return null;
	}
	

}
