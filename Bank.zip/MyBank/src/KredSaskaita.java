
import java.math.BigDecimal;

public class KredSaskaita extends Saskaita {
	
	
	private BigDecimal limitas;

	public KredSaskaita(BigDecimal limitas, String name) {
		super(name);
		this.limitas = limitas;
	
	}
	
	
	@Override
	public boolean withdraw(BigDecimal amount) {
		
		BigDecimal limit= this.limitas;
		
		BigDecimal balansas= super.getBalance();
		
	
		if (amount.compareTo(balansas) >= 0) {
			limit = limit.subtract(amount.subtract(balansas)); 
			limit=limit.negate();
		
		}
		return true;
	}		
		
			
	
}
