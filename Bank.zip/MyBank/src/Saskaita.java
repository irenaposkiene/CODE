import java.math.BigDecimal;
import java.util.UUID;

import ibank.Account;

public class Saskaita implements Account {
	
	private BigDecimal balance;
	private String name;
	private String number;
	


	
	public Saskaita(String name) {
		
		this.balance = new BigDecimal(0);
		this.name = name;
		this.number =  UUID.randomUUID().toString();
	}

	@Override
	public boolean deposit(BigDecimal amount) {
		this.balance = this.balance.add(amount);
		return true;
	}

	@Override
	public BigDecimal getBalance() {
		// TODO Auto-generated method stub
		return this.balance;
	}

	@Override
	public String getHolderName() {
		return this.name;
	}

	@Override
	public String getNumber() {
		return this.number;
	}

	@Override
	public boolean withdraw(BigDecimal amount) {
		if (amount.compareTo(balance) <= 0) {
			this.balance = this.balance.subtract(amount);
		}
		
		return true;
		
		
	}

}
