import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;

import lt.infobalt.itakademija.javalang.exam.socialnetwork.Friend;
import lt.infobalt.itakademija.javalang.exam.socialnetwork.FriendNotFoundException;
import lt.infobalt.itakademija.javalang.exam.socialnetwork.SocialNetwork;

public class MySocialNetwork implements SocialNetwork {
	
	
	Collection <Friend> myFriendList = new HashSet<Friend>();



	@Override
	public void addFriend(Friend f) {
		// TODO Auto-generated method stub
		if ( f == null){
			throw new IllegalArgumentException();
			}
		
			myFriendList.add(f);
			
	}

	@Override
	public Collection<Friend> findByCity(String miestas) {
		// TODO Auto-generated method stub
		List<Friend> listByCity= new ArrayList<>();
		for(Friend list :myFriendList){
			if (list.getCity().equals(miestas)){
				listByCity.add(list);
			}
		}
		return listByCity;
	}

	@Override
	public Friend findFriend(String firstName, String lastName) throws FriendNotFoundException {
		// TODO Auto-generated method stub
		if (firstName == null && lastName == null){
			throw new IllegalArgumentException();
		}
		for(Friend list :myFriendList){
			if (list.getFirstName().equals(firstName)&& list.getLastName().equals(lastName)){
				return list;
		}
			
		}
		throw new MyFriendNotFoundException(firstName, lastName);
		
	}

	@Override
	public int getNumberOfFriends() {
		// TODO Auto-generated method stub
		return myFriendList.size();
	}
	

	 
	@Override
	public Collection<Friend> getOrderedFriends() {
		// TODO Auto-generated method stub
		
		List<Friend> listFriends= new ArrayList<>();
		for(Friend list :myFriendList){
			listFriends.add(list);
			
		
		}
		return listFriends;
	
		
	}		
}
