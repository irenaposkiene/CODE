import lt.infobalt.itakademija.javalang.exam.socialnetwork.FriendNotFoundException;

public class MyFriendNotFoundException extends FriendNotFoundException {

	public MyFriendNotFoundException(String firstName, String lastName) {
		super(firstName, lastName);
		// TODO Auto-generated constructor stub
	}



}
