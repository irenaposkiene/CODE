import lt.infobalt.itakademija.javalang.exam.socialnetwork.Friend;

public class MyFriend extends Friend implements Comparable<Friend>  {
	
	private static String firstName;
	private static String city;
	private static String lastName;

	public MyFriend(String firstName, String lastName, String city) {
		super(firstName, lastName, city);
		// TODO Auto-generated constructor stub
	}
	
	public MyFriend() {
		super(firstName, lastName, city);
		// TODO Auto-generated constructor stub
	}

	 public int compare(MyFriend d, MyFriend c) {
	      return c.getLastName().compareTo(d.getLastName());
	   }


	@Override
	public int compareTo(Friend b) {
		// TODO Auto-generated method stub
		return super.getLastName().compareTo(b.getLastName());
	}
	}
	


