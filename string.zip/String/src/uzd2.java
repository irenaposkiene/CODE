import java.util.Locale;
import java.util.Scanner;

public class uzd2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner reader = new Scanner(System.in);
		
		System.out.print("Type a word:  ");
		
		String word = reader.nextLine();
		
		String word2 = word.toUpperCase();
		
		char a = word.charAt(0);
	

		char b = word2.charAt(0);
		
		
		if (a==b){
			System.out.print(" matched " );
		}
		
		else {
		System.out.print("not matched" );
		}
	
	}

}
