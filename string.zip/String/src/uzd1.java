import java.util.Scanner;

public class uzd1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner reader = new Scanner(System.in);
		
		System.out.print("Type a word:  ");
		
		String word = reader.nextLine();
		
		String  reverse = "";
		
	  	int length = word.length();
	 
	     for ( int i = length - 1; i >= 0; i-- )
	         reverse = reverse + word.charAt(i);
	 
	      if (word.equals(reverse))
	         System.out.println("Your word is a palindrome.");
	      else
	         System.out.println("Your word is is not a palindrome.");
	 
	      
		 

	}

}
