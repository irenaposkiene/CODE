import java.util.Scanner;

public class uzd3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner reader = new Scanner(System.in);
		
		System.out.print("Type a word:  ");
		String word = reader.nextLine();
		
		System.out.print("Type a character:  ");
		
		String ch = reader.nextLine();
		
		String a= "$";
			
		System.out.println(word.replaceAll(ch, a));
		
	
	      
		
	}

}
